/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BusanaService;

/**
 *
 * @author user
 */
import com.mycompany.SewaBusanaButik.Busana;

/**
 *
 * @author user
 */
public class BusanaTradisional extends Busana {
    private String asalDaerah;

    public BusanaTradisional(int id, String nama, double hargaSewa, String asalDaerah) {
        super(id, nama, hargaSewa);
        this.asalDaerah = asalDaerah;
    }

    public String getAsalDaerah() { return asalDaerah; }
    public void setAsalDaerah(String asalDaerah) { this.asalDaerah = asalDaerah; }

    @Override
    public String toString() {
        return super.toString() + " | Asal Daerah: " + asalDaerah;
    }    
}