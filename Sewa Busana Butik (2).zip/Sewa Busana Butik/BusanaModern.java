/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BusanaService;
import com.mycompany.SewaBusanaButik.Busana;

/**
 *
 * @author user
 */
public class BusanaModern extends Busana {
    private String kategori;

    public BusanaModern(int id, String nama, double hargaSewa, String kategori) {
        super(id, nama, hargaSewa);
        this.kategori = kategori;
    }

    public String getKategori() { return kategori; }
    public void setKategori(String kategori) { this.kategori = kategori; }

    @Override
    public String toString() {
        return super.toString() + " | Kategori: " + kategori;
    }
}   